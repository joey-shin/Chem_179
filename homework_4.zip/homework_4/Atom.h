#ifndef HOMEWORK_4_ATOM_H
#define HOMEWORK_4_ATOM_H

#include <iostream>
#include <vector>
#include <armadillo>

#include "GTO.h"
#include "STO3G.h"

struct Atom{
    vector<STO3G> AOs;
    vec coord;
    int atomic_number;
};

struct basis{
    vector<STO3G> basis;

};


void construct_Atoms(vector<Atom>& Atoms, const string& mol_file);

#endif //HOMEWORK_4_ATOM_H
